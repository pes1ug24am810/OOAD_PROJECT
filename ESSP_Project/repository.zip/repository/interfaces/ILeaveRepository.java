package repository.interfaces;

import model.Leave;
import java.util.List;

public interface ILeaveRepository {

    boolean applyLeave(Leave leave);

    Leave getLeaveById(int leaveId);

    List<Leave> getLeavesByEmployee(int employeeId);

    boolean updateLeaveStatus(int leaveId, String status);

    int getLeaveBalance(int employeeId);

    boolean cancelLeave(int leaveId);
}